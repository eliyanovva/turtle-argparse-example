from setuptools import setup

setup(name='drawing',
      version='0.1',
      description='A package which draws right polygons.',
      long_description='The package can draw any kinds of a right polygon on the whiteboard.',
      #classifiers=[
      #  'Development Status :: 3 - Alpha',
      #  'License :: OSI Approved :: MIT License',
      #  'Programming Language :: Python :: 2.7',
      #  'Topic :: Text Processing :: Linguistic',
      #],
      url='https://github.com/eliyanovva/turtle-argparse-example',
      author='Tedy',
      author_email='tedy@example.com',
      license='MIT',
      packages=['drawing'],
      install_requires=[
          'turtle', 'time', 'argparse'
      ],
      #test_suite='nose.collector',
      #tests_require=['nose', 'nose-cover3'],
      entry_points={
          'console_scripts': ['draw=drawing.main:main'],
      },
      #include_package_data=True,
      zip_safe=False)